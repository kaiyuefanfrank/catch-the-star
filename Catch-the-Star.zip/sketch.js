// Catch the Star — a small p5.js chase game.
// Mechanics: move toward the star; it flees; get close enough to score.

const GAME_WIDTH = 640;
const GAME_HEIGHT = 390;
const ROUND_SECONDS = 30;
const STAR_RADIUS = 22;
const FLEE_DISTANCE = 125;
const CATCH_DISTANCE = 33;

let starX = 320;
let starY = 195;
let score = 0;
let remaining = ROUND_SECONDS;
let playing = false;
let finishAt = 0;
let lastCatchAt = -1000;
let pointerX = -1000;
let pointerY = -1000;

function setup() {
  const canvas = createCanvas(GAME_WIDTH, GAME_HEIGHT);
  canvas.parent('canvas-holder');
  noStroke();
  document.getElementById('start-button').addEventListener('click', startGame);
}

function startGame() {
  score = 0;
  remaining = ROUND_SECONDS;
  starX = random(100, width - 100);
  starY = random(90, height - 90);
  pointerX = -1000;
  pointerY = -1000;
  lastCatchAt = -1000;
  finishAt = millis() + ROUND_SECONDS * 1000;
  playing = true;
  document.getElementById('start-button').textContent = 'Restart game';
  document.getElementById('status').textContent = 'Go get that star!';
  updateLabels();
}

function draw() {
  background(242, 236, 250);
  drawBackgroundDots();

  if (playing) {
    remaining = max(0, ceil((finishAt - millis()) / 1000));
    if (remaining === 0) {
      playing = false;
      document.getElementById('status').textContent =
        `Time's up! You scored ${score} point${score === 1 ? '' : 's'}.`;
    } else {
      updateStar();
    }
    updateLabels();
  }

  drawStar(starX, starY);
  if (playing && pointerX >= 0 && pointerX <= width && pointerY >= 0 && pointerY <= height) {
    stroke(132, 118, 171, 100);
    strokeWeight(1.5);
    line(pointerX - 7, pointerY, pointerX + 7, pointerY);
    line(pointerX, pointerY - 7, pointerX, pointerY + 7);
    noStroke();
  }
}

function updateStar() {
  const dx = starX - pointerX;
  const dy = starY - pointerY;
  const distance = sqrt(dx * dx + dy * dy);

  // A very close approach counts as a catch. The short pause prevents repeats.
  if (distance < CATCH_DISTANCE && millis() - lastCatchAt > 500) {
    score += 1;
    lastCatchAt = millis();
    starX = random(70, width - 70);
    starY = random(70, height - 70);
    document.getElementById('status').textContent = 'Nice catch! Keep going.';
    return;
  }

  // The star flees when the pointer enters its personal space.
  if (distance < FLEE_DISTANCE && distance > 0) {
    const speed = map(distance, 0, FLEE_DISTANCE, 2.5, 0.4);
    starX += (dx / distance) * speed;
    starY += (dy / distance) * speed;
  }

  // Keep the star inside the playable area.
  starX = constrain(starX, STAR_RADIUS + 10, width - STAR_RADIUS - 10);
  starY = constrain(starY, STAR_RADIUS + 10, height - STAR_RADIUS - 10);
}

function drawBackgroundDots() {
  fill(222, 214, 238);
  for (let x = 36; x < width; x += 72) {
    for (let y = 34; y < height; y += 72) {
      circle(x, y, 3);
    }
  }
}

function drawStar(x, y) {
  fill(255, 226, 142, 100);
  circle(x, y, 66);
  fill(243, 192, 70);
  beginShape();
  for (let i = 0; i < 10; i++) {
    const angle = -HALF_PI + i * PI / 5;
    const radius = i % 2 === 0 ? STAR_RADIUS : STAR_RADIUS * 0.48;
    vertex(x + cos(angle) * radius, y + sin(angle) * radius);
  }
  endShape(CLOSE);
}

function updateLabels() {
  document.getElementById('score').textContent = score;
  document.getElementById('time').textContent = remaining;
}

function mouseMoved() {
  pointerX = mouseX;
  pointerY = mouseY;
}

function mouseDragged() {
  pointerX = mouseX;
  pointerY = mouseY;
  return false;
}

function touchMoved() {
  pointerX = mouseX;
  pointerY = mouseY;
  return false;
}
