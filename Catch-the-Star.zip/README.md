# Catch the Star

A tiny chase game built with p5.js. The player moves the pointer toward a star, and the star flees. Get close enough to score as many points as possible in 30 seconds.

## Files

- `index.html`: required landing page with game title, explanation, and MDA write-up
- `game.html`: playable game page
- `sketch.js`: p5.js game logic
- `style.css`: page styling

## Run locally

Open `index.html` in a browser with internet access (p5.js loads from a CDN). For best results, use a local server such as VS Code Live Server or `python -m http.server 8000`.

## Publish to GitHub Pages

1. Create a public GitHub repository named `catch-the-star`.
2. Upload these four files and this README to the repository root.
3. Open repository **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**, branch **main**, folder **/(root)**, then Save.
5. Your landing page should appear at `https://YOUR-USERNAME.github.io/catch-the-star/` after deployment. Replace `YOUR-USERNAME` with your actual GitHub username.
6. Check that **Play the game** opens `game.html` and the game works.

## MDA

- **Mechanics:** pointer movement, proximity-based fleeing, close-range catches, scoring, and a 30-second timer.
- **Dynamics:** the star reacts to the player's approach, and scoring restarts the chase from a new location.
- **Aesthetics:** playful curiosity, mild challenge, and a soft visual atmosphere.

## Note

This project is a starting implementation. Play-test it, personalize it, and take a screenshot of the actual running game for your class submission.
